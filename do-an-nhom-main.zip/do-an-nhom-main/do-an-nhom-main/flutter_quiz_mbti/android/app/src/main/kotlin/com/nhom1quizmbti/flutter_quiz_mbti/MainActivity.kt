package com.nhom1quizmbti.flutter_quiz_mbti

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
