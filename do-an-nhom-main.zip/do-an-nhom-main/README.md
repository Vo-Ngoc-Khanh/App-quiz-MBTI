# do-an-nhom

Đồ án lập trình di động , tên đồ án : App trắc nghiệm tính cách (MBTI)

Thành viên nhóm :
- Võ Ngọc Khánh - 12001048
- Lê Sĩ Khang - 12001053
- Nguyễn Phước Tuấn - 12001019

Mô tả app : dựa vào ứng dụng đã được nghiên cứu MBTI khá nổi tiếng để nghiên cứu tính cách của mỗi người độ chính xác đến 80pt, gồm 70 câu hỏi, người dùng có 7-10 phút để hoàn thành phần câu hỏi, sau khi hoàn thành người dùng sẽ thuộc 1 trong 16 nhóm tính cách sau :
 - ISTJ - Người trách nhiệm 
 - ISFJ - Người nuôi dưỡng 
 - ISFP - Người nghệ sĩ 
 - ISTP - Nhà kỹ thuật 
 - INFP - Người lý tưởng hóa 
 - INFJ - Người che chở 
 - INTJ - Nhà khoa học 
 - INTP - Nhà tư duy 
 - ENFJ - Người cho đi 
 - ENFP - Người truyền cảm hứng 
 - ENTJ - Nhà điều hành 
 - ENTP - Người nhìn xa 
 - ESFJ - Người quan tâm 
 - ESFP - Người trình diễn 
 - ESTJ - Người giám hộ 
 - ESTP - Người thực thi
 Tài liệu tham khao để thực hiện dồ án : 
 - Cách thức để cho ra kết quả dựa vào kết quả người dùng chọn : tìm thuật toán của mbti
 - 70 câu hỏi và 16 loại tính cách : topcv.vn
